const express =require ("express");
const cors =require ("cors");
const mongoose = require('mongoose');


const app =express()

var corsoption ={
    origin :"http://localhost:4200"
};

app.use(cors(corsoption));

app.use(express.json());

app.use(express.urlencoded({extended :true}));

const db =require ("./models/todo.model");

const uri ="mongodb+srv://rutuja:rutuja@atlascluster.pzaazhu.mongodb.net/test?retryWrites=true&w=majority";
mongoose
.connect(uri ,{
    useNewUrlParser :true ,
    useUnifiedTopology :true
} )
.then (() =>{
    console.log("connected to database");
})
.catch(err => {
    console.log("can't connect to databse" ,err);
    process.exit();
});

app.get("/" ,(req,res) =>{
    res.json ({message :"TODO TASK"})
});



app.use("/",require ("./routes/todo.routes"));
 const PORT =process.env.PORT || 8000;
 app.listen(PORT ,()=>{
    console.log("server is running on port 8000")
 })