const todotask = require("../controllers/todo.controller");
var router = require("express").Router();
router.post("/todos", todotask.create);

router.get("/todos", todotask.findall);

router.put("/todos/:id", todotask.update);

router.delete("/delete/:id", todotask.delete);
module.exports = router;
