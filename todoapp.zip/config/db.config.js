module.exports = {
    uri: "mongodb+srv://rutuja:rutuja@atlascluster.pzaazhu.mongodb.net/test?retryWrites=true&w=majority"
  };
  