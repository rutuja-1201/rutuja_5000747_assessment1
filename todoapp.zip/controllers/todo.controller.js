const Todo = require("../models/todo.model").model;
//create new task
/*
exports.create =(req,res) => {
    if (!req.body.title) {
        res.status(400).send ({message : "content cannot be empty"});
        return;
    }


//create a task

const Todo =new Todo({
    Todo :req.body.Todo,
    description :req.body.description ,
    priority :req.body.priority? req.body.priority :false
});
}

exports.create = (req, res) => {
    
    const todo = new Todo(req.body);
  
    todo.save((err, task) => {
      if (err || !task) {
        return res.status(400).json({
          error: "something went wrong",
        });
      }
      
      res.json({ task });
    });
  };
  */

exports.create = (req, res) => {
  

    const {taskName, description, priority} = req.body;

  if (!taskName && !description && !priority) {
    res.status(400).send({ message: "Content can not be empty!" });
    return;
  }

  const todo1 = new Todo({
    taskName: req.body.taskName,
    description: req.body.description,
    priority: req.body.priority ? req.body.priority : false,
  });

  todo1.save()
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "some error occures while creating the task",
      });
    });
  
};

exports.findall = (req, res) => {
  const todo = req.query.Todo;
  var condition = todo
    ? {
        todo: { $regex: new RegExp(title), $options: "i" },
      }
    : {};

  Todo.find(condition)
    .then((data) => {
      res.send(data);
    })

    .catch((err) => {
      res.status(500).send({
        message: err.message || "some error occured",
      });
    });
};

exports.update = (req, res) => {
    /*
    if (!req.body) {
        return res.status(400).send({
          message: "Data to update can not be empty!"
        });
      }
    
      const id = req.params.id;
    
      Todo.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
        .then(data => {
          if (!data) {
            res.status(404).send({
              message: `Cannot update Tutorial with id=${id}. Maybe Tutorial was not found!`
            });
          } else res.send({ message: "Tutorial was updated successfully." });
        })
        .catch(err => {
          res.status(500).send({
            message: "Error updating Tutorial with id=" + id
          });
        });

*/
  Todo.findByIdAndUpdate(req.params.id,{
    $set:{taskName:req.body.taskName,description:req.body.description,priority:req.body.priority}
  })
  .then(data=>{
    res.send(data)
  })
  .catch(e=>{
    console.log(e)
  })
  
  
};
//const id =req.params.id ;

//Todo.findbyidandupdate

exports.delete = (req, res) => {
  const id = req.params.id;

  Todo.findByIdAndRemove(id, { usefindandmodify: false })
    .then((data) => {
      if (!data) {
        res.status(404).send({
          message: `no element found with id =${id}`,
        });
      } else {
        res.send({
          message: "task deleted succcessfully",
        });
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: "could not delete task"+err.message,
      });
    });
};
