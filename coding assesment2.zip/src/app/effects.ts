	import { Injectable } from '@angular/core';
	import { Actions, createEffect, ofType } from '@ngrx/effects';
	import { ProductService } from './product.service';
	import { map, mergeMap, catchError } from 'rxjs/operators';
import { of } from 'rxjs/internal/observable/of';
	
	@Injectable()
	export class ProductEffects {
		    constructor(private actions$: Actions, private productService: ProductService) { }
	
	    loadProducts$ = createEffect(() => this.actions$.pipe(
            ofType('[ProductList Component] GET_ALL_PRODUCTS'),
	        mergeMap(() => this.productService.getAllProducts()
	            .pipe(
	                map(products => ({ type: '[ProductList Component] GET_ALL_PRODUCTS SUCCESS', allProducts: products })),
	                catchError(() => of({ type: '[ProductList Component] GET_ALL_PRODUCTS ERROR', errorMessage: 'No Products Found' }))
	            ))));
                }
