import { Component,OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from '../products';
import {Store ,select} from '@ngrx/store'
import * as fromRoot from '../store/selector/products.selector'



@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit{
  constructor (private store :Store <fromRoot.AppState>){

  }

  products$:Observable<Product[]>=this.store.pipe(select (fromRoot.selectFeatureProduct))

  

  ngOnInit(): void {
      this.store.dispatch({type :'[ProductList component] GET_ALL_PRODUCTS'});
  }
  
}
/*
function select(selectFeatureProduct: any): any {
  throw new Error('Function not implemented.');
}
*/