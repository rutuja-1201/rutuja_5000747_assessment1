import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductListComponent } from './product-list/product-list.component';

import { HttpClient, HttpClientModule } from '@angular/common/http';
import {StoreModule ,ActionReducer ,MetaReducer} from '@ngrx/store';
import { prooductReducer } from './store/reducers/products.reducer';
import { EffectsModule } from '@ngrx/effects';
import { ProductEffects } from './effects';

export function debug (reducer :ActionReducer <any>):ActionReducer <any>{
  return function (state ,action){
    console.log('previous state' ,state);
    console.log('action' ,action);
    let nextState =reducer(state ,action);
    console.log('current state', nextState);
    return nextState;
  };
}
@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    StoreModule.forRoot({products :prooductReducer} ),
      EffectsModule.forRoot([ProductEffects])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
