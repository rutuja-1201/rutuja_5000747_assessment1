import {createReducer ,on} from '@ngrx/store';
import { getAllProducts ,getAllProductsAPIError, getAllProductsAPISuccess } from '../actions/products.action';

import { initialProductstate } from '../actions/states/products.store';
const _productReducer = createReducer(initialProductstate ,on(getAllProducts ,(state)=>state),
on(getAllProductsAPISuccess ,(state :any,{
    allProducts
}) => {return {...state ,allProducts:allProducts ,errorMessage:""}}),

on(getAllProductsAPIError ,(state :any,{errorMessage})=> {return {...state,errorMessage: errorMessage, allProducts:[]}})

);

export function prooductReducer(state :any ,action:any){
    return _productReducer(state,action);
}