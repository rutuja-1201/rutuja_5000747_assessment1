import {createAction,props} from '@ngrx/store';
import { Product } from 'src/app/products';

export const getAllProducts =createAction('[ProductList Component] GET_ALL_PRODUCTS')

export const getAllProductsAPISuccess = createAction('[ProductList Component] GET_ALL_PRODUCTS SUCCESS', props <{allProducts :Product[]}>() )


export const getAllProductsAPIError =createAction
('[ProductList Component] GET_ALL_PRODUCTS ERROR',props<{ errorMessage:String}>())