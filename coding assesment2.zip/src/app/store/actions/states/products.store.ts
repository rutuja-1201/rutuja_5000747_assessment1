export const initialProductstate ={
    allProducts :[],
    errorMessage :""
}