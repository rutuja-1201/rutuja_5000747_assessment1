export class Product {
    id :number =0;
    productName :string="";
    productPrice:number=0;
    productImg:string="";
    productBrand :string="";
}