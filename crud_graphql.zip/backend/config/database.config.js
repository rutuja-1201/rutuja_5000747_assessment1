module.exports = {
    url:'mongodb+srv://rutuja12:rutuja12@atlascluster.pzaazhu.mongodb.net/?retryWrites=true&w=majority'
}
