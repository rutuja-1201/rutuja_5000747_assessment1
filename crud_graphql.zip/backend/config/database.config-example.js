module.exports = {
    url: 'mongodb+srv://rutuja12:rutuja12@atlascluster.pzaazhu.mongodb.net/test?retryWrites=true&w=majority'

}