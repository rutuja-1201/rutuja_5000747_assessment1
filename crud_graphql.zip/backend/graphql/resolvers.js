const Customer = require("../models/customer");

module.exports = {
  listCustomers: async function () {
    const customer = await Customer.find();

    return {
      customers: customer.map((q) => {
        return {
          ...q._doc,
          _id: q._id.toString(),
        };
      }),
    };
  },
  createCustomer: async function ({ customerInput }) {
    const { name, address, phone, membership } = customerInput;
    const customer = new Customer({
      name,
      address,
      phone,
      membership,
    });
    const createdcustomer = await customer.save();
    return {
      ...createdcustomer._doc,
      _id: createdcustomer._id.toString(),
    };
  },
  updateCustomer: async function ({ id, customerInput }) {
    const customer = await Customer.findById(id);
    if (!customer) {
      throw new Error("No customer found!");
    }
    customer.name = customerInput.customer;
    customer.address = customerInput.address;
    customer.phone = customerInput.phone;
    customer.membership = customerInput.membership;
    const updatedCustomer = await customer.save();
    return {
      ...updatedCustomer._doc,
      _id: updatedCustomer._id.toString(),
    };
  },
  deleteCustomer: async function ({ id }) {
    const customer = await Customer.findById(id);
    if (!customer) {
      throw new Error("No quote found!");
    }
    await Customer.findByIdAndRemove(id);
    return {
      ...customer._doc,
      _id: customer._id.toString(),
    };
  },
};
