const { buildSchema } = require("graphql");

module.exports = buildSchema(`
    type Customer{
        _id: ID!
        name:String!
        address:String!
        phone :String!
        membership :String!
    }
    input CustomerInputData {
        name:String!
        address:String!
        phone :String!
        membership :String!
    }
    type CustomerData {
        customers: [Customer!]!
    }
    type RootQuery {
        listCustomers: CustomerData
    }
    type RootMutation {
        createCustomer(customerInput: CustomerInputData!): Customer!
        updateCustomer(id: ID!, customerInput: CustomerInputData!): Customer!
        deleteCustomer(id: ID!): Customer!
    }
    schema {
        query: RootQuery
        mutation: RootMutation
    }
`);
