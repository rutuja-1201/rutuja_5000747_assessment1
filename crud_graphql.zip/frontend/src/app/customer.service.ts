import { Injectable } from '@angular/core';
import {
  ADD_Customer,
  UPDATE_CUSTOMER,
  DELETE_CUSTOMER,
} from './graphql/mutation';
import { Customer } from './customer.model';
import { Observable } from 'rxjs';
import { LIST_Customer } from './graphql/queries';
import { Apollo } from 'apollo-angular';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CustomerService {
  constructor(private apollo: Apollo) {}

  listCustomer(): Observable<Customer[]> {
    return this.apollo.query({ query: LIST_Customer }).pipe(
      map((result: any) => {
        return result.data.customer;
      })
    );
  }

  addCustomer(reqBody: Customer): Observable<Customer> {
    return this.apollo
      .mutate({
        mutation: ADD_Customer,
        refetchQueries: [{ query: LIST_Customer }],
        variables: {
          input: reqBody,
        },
      })
      .pipe(
        map((result: any) => {
          console.log(result.data.addCustomer);
          return result.data.addCustomer;
        })
      );
  }
}
