import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerModule } from './customer/customer.module';
import { CustomerAddComponent } from './customer/customers-add/customers-add.component';
import { CustomerEditComponent } from './customer/customers-edit/customers-edit.component';
import { CustomersListComponent } from './customer/customers-list/customers-list.component';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component';

const routes: Routes = [
  {path : " " ,component :NavbarComponent},
  {path :"customers" ,component :CustomerAddComponent},
  {path : "edit" , component :CustomerEditComponent},
  {path :"list" ,component :CustomersListComponent},
  {path :"" ,component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
