import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Customer } from 'src/app/customer.model';
import { createCustomer, CustomerActionTypes } from '../state/customer.actions';
import { CustomerService } from 'src/app/customer.service';

@Component({
  selector: 'app-customers-add',
  templateUrl: './customers-add.component.html',
  styleUrls: ['./customers-add.component.css'],
})
export class CustomerAddComponent implements OnInit {
  customerForm!: FormGroup;
  customerActions: any;
  constructor(
    private fb: FormBuilder,
    private store: Store<CustomerActionTypes>,
    private customerservice: CustomerService
  ) {}

  ngOnInit() {
    this.customerForm = this.fb.group({
      name: ['', Validators.required],
      phone: ['', Validators.required],
      address: ['', Validators.required],
      membership: ['', Validators.required],
    });
  }

  createCustomer() {
    const newCustomer: Customer = {
      name: this.customerForm.get('name')?.value,
      phone: this.customerForm.get('phone')?.value,
      address: this.customerForm.get('address')?.value,
      membership: this.customerForm.get('membership')?.value,
    };

    this.customerservice.addCustomer(newCustomer).subscribe(
      (value) => {
        console.log(value);
        //this.store.dispatch(this.customerActions.createCustomer(newCustomer));
        this.store.dispatch(createCustomer({ customer: value }));
        this.customerForm.reset();
      },
      (error) => console.log(error)
    );
  }
}
