import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomersComponent } from './customers/customers.component';
import { CustomerAddComponent } from './customers-add/customers-add.component';
import { CustomerEditComponent } from './customers-edit/customers-edit.component';
import { CustomersListComponent } from './customers-list/customers-list.component';
import {StoreModule} from "@ngrx/store";
import { Route, RouterModule ,Routes } from '@angular/router';
import {customerReducer} from "./state/customer.reducer";


import { ReactiveFormsModule ,FormsModule } from '@angular/forms';
//define customer routes
const customerroutes :Routes =[{ path : " " ,component :CustomersComponent}];

@NgModule({
  declarations: [
    CustomersComponent,
    CustomerAddComponent,
    CustomerEditComponent,
    CustomersListComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(customerroutes),
    StoreModule.forFeature(" customers" ,customerReducer),
  ]
})
export class CustomerModule { }
