export class Customer{
    name! :String;
    phone! :number;
    address ! :String;
    membership!:String
  id?: any;
}