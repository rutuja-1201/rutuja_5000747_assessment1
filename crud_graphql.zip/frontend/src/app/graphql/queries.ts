import { gql } from 'apollo-angular';

export const LIST_Customer = gql`
  query listCustomers {
    listCustomers {
      customers {
        _id
        name
        phone
        membership
        address
      }
    }
  }
`;
export const ADD_Customer = gql`
  query getcustomerDetails($id: Int!) {
    createCustomer(id: $id) {
      name
      address
      phone
      membership
    }
  }
`;
