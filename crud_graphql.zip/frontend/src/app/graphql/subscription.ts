import { gql } from 'apollo-angular';

export const SUBSCRIBE_TODO = gql`
  subscription customer{
    customer {
      mutation
      data {
         name
         phone
         address
         membership
        _id
      }
    }
  }
`;

