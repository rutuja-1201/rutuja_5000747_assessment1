import { gql } from 'apollo-angular';

export const ADD_Customer = gql`
  mutation createCustomer($input: CustomerInputData!) {
    createCustomer(customerInput: $input) {
      _id
      name
      phone
      address
      membership
    }
  }
`;

export const UPDATE_CUSTOMER = gql`
  mutation editCustomer($input: CustomerInputData!) {
    editCustomer(customerinput: $input) {
      _id
      name
      phone
      address
      membership
    }
  }
`;

export const DELETE_CUSTOMER = gql`
  mutation deleteCustomer($id: Int!) {
    deleteCustomer(id: $id) {
      _id
      name
      phone
      address
      membership
    }
  }
`;
