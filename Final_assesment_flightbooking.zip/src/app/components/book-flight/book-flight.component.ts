import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { APIService, Passenger } from 'src/app/API.service';
import { ReactiveFormsModule } from '@angular/forms';
import { book } from 'src/app/store/action';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.css'],
})
export class BookFlightComponent implements OnInit {
  [x: string]: any;
  createform!: FormGroup;
  name!: string;
  noofticket!: Number;
  flightid!: String;
  passengers!: Passenger[];

  constructor(
    private api: APIService,
    private formbuild: FormBuilder,
    private store: Store
  ) {}

  ngOnInit() {
    this.api.ListPassengers().then((data) => {
      this.passengers = data.items as Passenger[];
    });

    this.createform = this.formbuild.group({
      name: ['', Validators.required],
      noofticket: [
        '',
        Validators.required,
        Validators.min(1),
        Validators.max(40),
      ],

      flightid: ['', Validators.required, Validators.minLength(7)],
    });
  }

  public oncreate(passenger: Passenger) {
    this.api
      .CreatePassenger(passenger)
      .then((data) => {
        console.log(data);
        console.log('booking added');
        this.createform.reset();
      })
      .catch((e) => {
        console.log('error' + e);
      });
  }

  onSubmit() {
    this.store.dispatch(book());
  }
}
