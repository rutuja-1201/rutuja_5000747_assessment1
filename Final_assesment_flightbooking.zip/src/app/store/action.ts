import { createAction, props } from '@ngrx/store';

export const book = createAction(
  '[BOOKING] book',
  props<{ name: string; noofticket: number; flightid: string }>
);

export const viewlist = createAction(
  '[VIEWLIST] View',
  props<{ name: string; noofticket: number; flightid: string }>
);
