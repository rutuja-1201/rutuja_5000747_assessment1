import { state } from '@angular/animations';
import { createReducer, Action, on } from '@ngrx/store';
import * as flightAction from '../store/action';

export interface State {
  name: string;
  noofticket: number;
  flightid: string;
}

export const initialState: State = {
  name: '',
  noofticket: 0,
  flightid: '',
};

const bookreducer = createReducer(
  initialState,
  on(flightAction.book, (state) => ({ ...state })),
  on(flightAction.viewlist, (state) => ({ ...state }))
);

export function reducer(state: State, action: Action) {
  return bookreducer(state, action);
}
