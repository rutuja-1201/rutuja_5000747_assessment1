/* tslint:disable */
/* eslint-disable */
//  This file was automatically generated and should not be edited.
import { Injectable } from "@angular/core";
import API, { graphqlOperation, GraphQLResult } from "@aws-amplify/api-graphql";
import { Observable } from "zen-observable-ts";

export interface SubscriptionResponse<T> {
  value: GraphQLResult<T>;
}

export type __SubscriptionContainer = {
  onCreateFlight: OnCreateFlightSubscription;
  onUpdateFlight: OnUpdateFlightSubscription;
  onDeleteFlight: OnDeleteFlightSubscription;
  onCreatePassenger: OnCreatePassengerSubscription;
  onUpdatePassenger: OnUpdatePassengerSubscription;
  onDeletePassenger: OnDeletePassengerSubscription;
};

export type CreateFlightInput = {
  id?: string | null;
  name: string;
};

export type ModelFlightConditionInput = {
  name?: ModelStringInput | null;
  and?: Array<ModelFlightConditionInput | null> | null;
  or?: Array<ModelFlightConditionInput | null> | null;
  not?: ModelFlightConditionInput | null;
};

export type ModelStringInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
  size?: ModelSizeInput | null;
};

export enum ModelAttributeTypes {
  binary = "binary",
  binarySet = "binarySet",
  bool = "bool",
  list = "list",
  map = "map",
  number = "number",
  numberSet = "numberSet",
  string = "string",
  stringSet = "stringSet",
  _null = "_null"
}

export type ModelSizeInput = {
  ne?: number | null;
  eq?: number | null;
  le?: number | null;
  lt?: number | null;
  ge?: number | null;
  gt?: number | null;
  between?: Array<number | null> | null;
};

export type Flight = {
  __typename: "Flight";
  id: string;
  name: string;
  passenger?: ModelPassengerConnection | null;
  createdAt: string;
  updatedAt: string;
};

export type ModelPassengerConnection = {
  __typename: "ModelPassengerConnection";
  items: Array<Passenger | null>;
  nextToken?: string | null;
};

export type Passenger = {
  __typename: "Passenger";
  id: string;
  name: string;
  tickets: number;
  flightid: string;
  createdAt: string;
  updatedAt: string;
  flightPassengerId?: string | null;
};

export type UpdateFlightInput = {
  id: string;
  name?: string | null;
};

export type DeleteFlightInput = {
  id: string;
};

export type CreatePassengerInput = {
  id?: string | null;
  name: string;
  tickets: number;
  flightid: string;
  flightPassengerId?: string | null;
};

export type ModelPassengerConditionInput = {
  name?: ModelStringInput | null;
  tickets?: ModelIntInput | null;
  flightid?: ModelStringInput | null;
  and?: Array<ModelPassengerConditionInput | null> | null;
  or?: Array<ModelPassengerConditionInput | null> | null;
  not?: ModelPassengerConditionInput | null;
  flightPassengerId?: ModelIDInput | null;
};

export type ModelIntInput = {
  ne?: number | null;
  eq?: number | null;
  le?: number | null;
  lt?: number | null;
  ge?: number | null;
  gt?: number | null;
  between?: Array<number | null> | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
};

export type ModelIDInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
  size?: ModelSizeInput | null;
};

export type UpdatePassengerInput = {
  id: string;
  name?: string | null;
  tickets?: number | null;
  flightid?: string | null;
  flightPassengerId?: string | null;
};

export type DeletePassengerInput = {
  id: string;
};

export type ModelFlightFilterInput = {
  id?: ModelIDInput | null;
  name?: ModelStringInput | null;
  and?: Array<ModelFlightFilterInput | null> | null;
  or?: Array<ModelFlightFilterInput | null> | null;
  not?: ModelFlightFilterInput | null;
};

export type ModelFlightConnection = {
  __typename: "ModelFlightConnection";
  items: Array<Flight | null>;
  nextToken?: string | null;
};

export type ModelPassengerFilterInput = {
  id?: ModelIDInput | null;
  name?: ModelStringInput | null;
  tickets?: ModelIntInput | null;
  flightid?: ModelStringInput | null;
  and?: Array<ModelPassengerFilterInput | null> | null;
  or?: Array<ModelPassengerFilterInput | null> | null;
  not?: ModelPassengerFilterInput | null;
  flightPassengerId?: ModelIDInput | null;
};

export type ModelSubscriptionFlightFilterInput = {
  id?: ModelSubscriptionIDInput | null;
  name?: ModelSubscriptionStringInput | null;
  and?: Array<ModelSubscriptionFlightFilterInput | null> | null;
  or?: Array<ModelSubscriptionFlightFilterInput | null> | null;
};

export type ModelSubscriptionIDInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  in?: Array<string | null> | null;
  notIn?: Array<string | null> | null;
};

export type ModelSubscriptionStringInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  in?: Array<string | null> | null;
  notIn?: Array<string | null> | null;
};

export type ModelSubscriptionPassengerFilterInput = {
  id?: ModelSubscriptionIDInput | null;
  name?: ModelSubscriptionStringInput | null;
  tickets?: ModelSubscriptionIntInput | null;
  flightid?: ModelSubscriptionStringInput | null;
  and?: Array<ModelSubscriptionPassengerFilterInput | null> | null;
  or?: Array<ModelSubscriptionPassengerFilterInput | null> | null;
};

export type ModelSubscriptionIntInput = {
  ne?: number | null;
  eq?: number | null;
  le?: number | null;
  lt?: number | null;
  ge?: number | null;
  gt?: number | null;
  between?: Array<number | null> | null;
  in?: Array<number | null> | null;
  notIn?: Array<number | null> | null;
};

export type CreateFlightMutation = {
  __typename: "Flight";
  id: string;
  name: string;
  passenger?: {
    __typename: "ModelPassengerConnection";
    items: Array<{
      __typename: "Passenger";
      id: string;
      name: string;
      tickets: number;
      flightid: string;
      createdAt: string;
      updatedAt: string;
      flightPassengerId?: string | null;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type UpdateFlightMutation = {
  __typename: "Flight";
  id: string;
  name: string;
  passenger?: {
    __typename: "ModelPassengerConnection";
    items: Array<{
      __typename: "Passenger";
      id: string;
      name: string;
      tickets: number;
      flightid: string;
      createdAt: string;
      updatedAt: string;
      flightPassengerId?: string | null;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type DeleteFlightMutation = {
  __typename: "Flight";
  id: string;
  name: string;
  passenger?: {
    __typename: "ModelPassengerConnection";
    items: Array<{
      __typename: "Passenger";
      id: string;
      name: string;
      tickets: number;
      flightid: string;
      createdAt: string;
      updatedAt: string;
      flightPassengerId?: string | null;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type CreatePassengerMutation = {
  __typename: "Passenger";
  id: string;
  name: string;
  tickets: number;
  flightid: string;
  createdAt: string;
  updatedAt: string;
  flightPassengerId?: string | null;
};

export type UpdatePassengerMutation = {
  __typename: "Passenger";
  id: string;
  name: string;
  tickets: number;
  flightid: string;
  createdAt: string;
  updatedAt: string;
  flightPassengerId?: string | null;
};

export type DeletePassengerMutation = {
  __typename: "Passenger";
  id: string;
  name: string;
  tickets: number;
  flightid: string;
  createdAt: string;
  updatedAt: string;
  flightPassengerId?: string | null;
};

export type GetFlightQuery = {
  __typename: "Flight";
  id: string;
  name: string;
  passenger?: {
    __typename: "ModelPassengerConnection";
    items: Array<{
      __typename: "Passenger";
      id: string;
      name: string;
      tickets: number;
      flightid: string;
      createdAt: string;
      updatedAt: string;
      flightPassengerId?: string | null;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type ListFlightsQuery = {
  __typename: "ModelFlightConnection";
  items: Array<{
    __typename: "Flight";
    id: string;
    name: string;
    passenger?: {
      __typename: "ModelPassengerConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
};

export type GetPassengerQuery = {
  __typename: "Passenger";
  id: string;
  name: string;
  tickets: number;
  flightid: string;
  createdAt: string;
  updatedAt: string;
  flightPassengerId?: string | null;
};

export type ListPassengersQuery = {
  __typename: "ModelPassengerConnection";
  items: Array<{
    __typename: "Passenger";
    id: string;
    name: string;
    tickets: number;
    flightid: string;
    createdAt: string;
    updatedAt: string;
    flightPassengerId?: string | null;
  } | null>;
  nextToken?: string | null;
};

export type OnCreateFlightSubscription = {
  __typename: "Flight";
  id: string;
  name: string;
  passenger?: {
    __typename: "ModelPassengerConnection";
    items: Array<{
      __typename: "Passenger";
      id: string;
      name: string;
      tickets: number;
      flightid: string;
      createdAt: string;
      updatedAt: string;
      flightPassengerId?: string | null;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type OnUpdateFlightSubscription = {
  __typename: "Flight";
  id: string;
  name: string;
  passenger?: {
    __typename: "ModelPassengerConnection";
    items: Array<{
      __typename: "Passenger";
      id: string;
      name: string;
      tickets: number;
      flightid: string;
      createdAt: string;
      updatedAt: string;
      flightPassengerId?: string | null;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type OnDeleteFlightSubscription = {
  __typename: "Flight";
  id: string;
  name: string;
  passenger?: {
    __typename: "ModelPassengerConnection";
    items: Array<{
      __typename: "Passenger";
      id: string;
      name: string;
      tickets: number;
      flightid: string;
      createdAt: string;
      updatedAt: string;
      flightPassengerId?: string | null;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type OnCreatePassengerSubscription = {
  __typename: "Passenger";
  id: string;
  name: string;
  tickets: number;
  flightid: string;
  createdAt: string;
  updatedAt: string;
  flightPassengerId?: string | null;
};

export type OnUpdatePassengerSubscription = {
  __typename: "Passenger";
  id: string;
  name: string;
  tickets: number;
  flightid: string;
  createdAt: string;
  updatedAt: string;
  flightPassengerId?: string | null;
};

export type OnDeletePassengerSubscription = {
  __typename: "Passenger";
  id: string;
  name: string;
  tickets: number;
  flightid: string;
  createdAt: string;
  updatedAt: string;
  flightPassengerId?: string | null;
};

@Injectable({
  providedIn: "root"
})
export class APIService {
  async CreateFlight(
    input: CreateFlightInput,
    condition?: ModelFlightConditionInput
  ): Promise<CreateFlightMutation> {
    const statement = `mutation CreateFlight($input: CreateFlightInput!, $condition: ModelFlightConditionInput) {
        createFlight(input: $input, condition: $condition) {
          __typename
          id
          name
          passenger {
            __typename
            items {
              __typename
              id
              name
              tickets
              flightid
              createdAt
              updatedAt
              flightPassengerId
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateFlightMutation>response.data.createFlight;
  }
  async UpdateFlight(
    input: UpdateFlightInput,
    condition?: ModelFlightConditionInput
  ): Promise<UpdateFlightMutation> {
    const statement = `mutation UpdateFlight($input: UpdateFlightInput!, $condition: ModelFlightConditionInput) {
        updateFlight(input: $input, condition: $condition) {
          __typename
          id
          name
          passenger {
            __typename
            items {
              __typename
              id
              name
              tickets
              flightid
              createdAt
              updatedAt
              flightPassengerId
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateFlightMutation>response.data.updateFlight;
  }
  async DeleteFlight(
    input: DeleteFlightInput,
    condition?: ModelFlightConditionInput
  ): Promise<DeleteFlightMutation> {
    const statement = `mutation DeleteFlight($input: DeleteFlightInput!, $condition: ModelFlightConditionInput) {
        deleteFlight(input: $input, condition: $condition) {
          __typename
          id
          name
          passenger {
            __typename
            items {
              __typename
              id
              name
              tickets
              flightid
              createdAt
              updatedAt
              flightPassengerId
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteFlightMutation>response.data.deleteFlight;
  }
  async CreatePassenger(
    input: CreatePassengerInput,
    condition?: ModelPassengerConditionInput
  ): Promise<CreatePassengerMutation> {
    const statement = `mutation CreatePassenger($input: CreatePassengerInput!, $condition: ModelPassengerConditionInput) {
        createPassenger(input: $input, condition: $condition) {
          __typename
          id
          name
          tickets
          flightid
          createdAt
          updatedAt
          flightPassengerId
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreatePassengerMutation>response.data.createPassenger;
  }
  async UpdatePassenger(
    input: UpdatePassengerInput,
    condition?: ModelPassengerConditionInput
  ): Promise<UpdatePassengerMutation> {
    const statement = `mutation UpdatePassenger($input: UpdatePassengerInput!, $condition: ModelPassengerConditionInput) {
        updatePassenger(input: $input, condition: $condition) {
          __typename
          id
          name
          tickets
          flightid
          createdAt
          updatedAt
          flightPassengerId
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdatePassengerMutation>response.data.updatePassenger;
  }
  async DeletePassenger(
    input: DeletePassengerInput,
    condition?: ModelPassengerConditionInput
  ): Promise<DeletePassengerMutation> {
    const statement = `mutation DeletePassenger($input: DeletePassengerInput!, $condition: ModelPassengerConditionInput) {
        deletePassenger(input: $input, condition: $condition) {
          __typename
          id
          name
          tickets
          flightid
          createdAt
          updatedAt
          flightPassengerId
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeletePassengerMutation>response.data.deletePassenger;
  }
  async GetFlight(id: string): Promise<GetFlightQuery> {
    const statement = `query GetFlight($id: ID!) {
        getFlight(id: $id) {
          __typename
          id
          name
          passenger {
            __typename
            items {
              __typename
              id
              name
              tickets
              flightid
              createdAt
              updatedAt
              flightPassengerId
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetFlightQuery>response.data.getFlight;
  }
  async ListFlights(
    filter?: ModelFlightFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListFlightsQuery> {
    const statement = `query ListFlights($filter: ModelFlightFilterInput, $limit: Int, $nextToken: String) {
        listFlights(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            name
            passenger {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          nextToken
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListFlightsQuery>response.data.listFlights;
  }
  async GetPassenger(id: string): Promise<GetPassengerQuery> {
    const statement = `query GetPassenger($id: ID!) {
        getPassenger(id: $id) {
          __typename
          id
          name
          tickets
          flightid
          createdAt
          updatedAt
          flightPassengerId
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetPassengerQuery>response.data.getPassenger;
  }
  async ListPassengers(
    filter?: ModelPassengerFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListPassengersQuery> {
    const statement = `query ListPassengers($filter: ModelPassengerFilterInput, $limit: Int, $nextToken: String) {
        listPassengers(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            name
            tickets
            flightid
            createdAt
            updatedAt
            flightPassengerId
          }
          nextToken
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListPassengersQuery>response.data.listPassengers;
  }
  OnCreateFlightListener(
    filter?: ModelSubscriptionFlightFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateFlight">>
  > {
    const statement = `subscription OnCreateFlight($filter: ModelSubscriptionFlightFilterInput) {
        onCreateFlight(filter: $filter) {
          __typename
          id
          name
          passenger {
            __typename
            items {
              __typename
              id
              name
              tickets
              flightid
              createdAt
              updatedAt
              flightPassengerId
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateFlight">>
    >;
  }

  OnUpdateFlightListener(
    filter?: ModelSubscriptionFlightFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateFlight">>
  > {
    const statement = `subscription OnUpdateFlight($filter: ModelSubscriptionFlightFilterInput) {
        onUpdateFlight(filter: $filter) {
          __typename
          id
          name
          passenger {
            __typename
            items {
              __typename
              id
              name
              tickets
              flightid
              createdAt
              updatedAt
              flightPassengerId
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateFlight">>
    >;
  }

  OnDeleteFlightListener(
    filter?: ModelSubscriptionFlightFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteFlight">>
  > {
    const statement = `subscription OnDeleteFlight($filter: ModelSubscriptionFlightFilterInput) {
        onDeleteFlight(filter: $filter) {
          __typename
          id
          name
          passenger {
            __typename
            items {
              __typename
              id
              name
              tickets
              flightid
              createdAt
              updatedAt
              flightPassengerId
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteFlight">>
    >;
  }

  OnCreatePassengerListener(
    filter?: ModelSubscriptionPassengerFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onCreatePassenger">>
  > {
    const statement = `subscription OnCreatePassenger($filter: ModelSubscriptionPassengerFilterInput) {
        onCreatePassenger(filter: $filter) {
          __typename
          id
          name
          tickets
          flightid
          createdAt
          updatedAt
          flightPassengerId
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onCreatePassenger">>
    >;
  }

  OnUpdatePassengerListener(
    filter?: ModelSubscriptionPassengerFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdatePassenger">>
  > {
    const statement = `subscription OnUpdatePassenger($filter: ModelSubscriptionPassengerFilterInput) {
        onUpdatePassenger(filter: $filter) {
          __typename
          id
          name
          tickets
          flightid
          createdAt
          updatedAt
          flightPassengerId
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdatePassenger">>
    >;
  }

  OnDeletePassengerListener(
    filter?: ModelSubscriptionPassengerFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onDeletePassenger">>
  > {
    const statement = `subscription OnDeletePassenger($filter: ModelSubscriptionPassengerFilterInput) {
        onDeletePassenger(filter: $filter) {
          __typename
          id
          name
          tickets
          flightid
          createdAt
          updatedAt
          flightPassengerId
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onDeletePassenger">>
    >;
  }
}
