import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { AuthComponent } from './components/auth/auth.component';
import { BookFlightComponent } from './components/book-flight/book-flight.component';
import { HomeComponent } from './components/home/home.component';
import { ViewFlightComponent } from './components/view-flight/view-flight.component';

const routes: Routes = [
  { path: '', component: AuthComponent },
  { path: 'booking', component: BookFlightComponent },
  { path: 'viewflight', component: ViewFlightComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
