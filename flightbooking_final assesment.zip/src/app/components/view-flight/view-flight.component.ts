import { Component, OnInit } from '@angular/core';

import { APIService, Passenger } from 'src/app/API.service';

@Component({
  selector: 'app-view-flight',
  templateUrl: './view-flight.component.html',
  styleUrls: ['./view-flight.component.css'],
})
export class ViewFlightComponent implements OnInit {
  passengers!: Passenger[];
  name!: string;
  id!: string;
  noofticket?: Number;
  flightid!: string;
  flightPassengerId?: string;

  constructor(private api: APIService) {}
  ngOnInit() {
    this.api.ListPassengers().then((data) => {
      this.passengers = data.items as Passenger[];
    });
  }

  public onDelete(passenger: Passenger) {
    let delid = {
      id: passenger.id,
    };
    this.api
      .DeletePassenger(delid)
      .then((data) => {
        console.log(data);
        console.log('booking deleted');
      })
      .catch((e) => {
        console.log(e + 'error');
      });
  }

  public onUpdate(passenger: Passenger) {
    const obj = {
      id: this.flightid,
      name: this.name,
      noofticket: this.noofticket,

      flightid: this.flightid,
      flightPassengerId: this.flightPassengerId,
    };

    this.api.UpdatePassenger(obj).then((data) => {
      console.log(data);
    });
  }
}
